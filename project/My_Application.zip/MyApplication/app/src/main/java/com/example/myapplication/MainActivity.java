package com.example.myapplication;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.R;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MarkerOptions;

public class MainActivity extends AppCompatActivity implements OnMapReadyCallback {

    private GoogleMap gMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);

        if (mapFragment != null) {
            mapFragment.getMapAsync(this);

        }

    }


    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        gMap = googleMap;

        // ✅ Define coordinates
        LatLng davao = new LatLng(7.0647, 125.6088);
        LatLng cotabato = new LatLng(7.2042, 124.2464);
        LatLng gensan = new LatLng(6.1164, 125.1716);

        // ✅ Add markers
        gMap.addMarker(new MarkerOptions().position(davao).title("Davao City"));
        gMap.addMarker(new MarkerOptions().position(cotabato).title("Cotabato City"));
        gMap.addMarker(new MarkerOptions().position(gensan).title("General Santos City"));

        // ✅ Build bounds to show all markers
        LatLngBounds bounds = new LatLngBounds.Builder()
                .include(davao)
                .include(cotabato)
                .include(gensan)
                .build();

        // ✅ Move camera once map layout is ready (prevents crash)
        gMap.setOnMapLoadedCallback(() ->
                gMap.moveCamera(CameraUpdateFactory.newLatLngBounds(bounds, 100))
        );
    }
}